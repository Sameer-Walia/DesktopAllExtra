$(".sun").hide()
$(".moon").click(function(){
    $(".moon").hide()
    $(".sun").show()
    $(".theme1").css({backgroundColor:"#182C44"})
    $(".theme2").css({backgroundColor:"#112339"})
    $("h1,h2,h3,h4,h5,h6,a,#services span,#solution li,#solution li span,.size").css({color:"white"})
    $(".ss").css({color:"black"})
    $("p").css({color:"#c2c2c2"})
    $(".navbar h3").css({color:"#e4c904"})
    $("#solution .nav-item button").css({backgroundColor:"#112339",color:"white"})
    $("#solution .accordion-item,.accordion-button").css({backgroundColor:"#182C44",color:"white"})
    $("#gallery h6").css({color:"black"})

})
$(".sun").click(function(){
    $(".sun").hide()
    $(".moon").show()
    $(".theme1").css({backgroundColor:""})
    $(".theme2").css({backgroundColor:""})
    $("h1,h2,h3,h4,h5,h6,a,#services span,#solution li,#solution li span,.size").css({color:""})
    $(".ss").css({color:""})
    $("p").css({color:""})
    $("#solution .nav-item button").css({backgroundColor:"",color:""})
    $("#solution .accordion-item,.accordion-button").css({backgroundColor:"",color:""})
})


$(document).ready(function() {
    $("#news-slider").owlCarousel({
        items : 3,
        itemsDesktop:[1199,3],
        itemsDesktopSmall:[980,2],
        itemsMobile : [600,1],
        navigation:true,
        navigationText:["",""],
        pagination:true,
        autoPlay:true
    });
});
// owl crousel js close


$(function(){
	$('.mhn-slide').owlCarousel({
		nav:true,
		//loop:true,
		slideBy:'page',
		rewind:false,
		responsive:{
			0:{items:1},
			480:{items:2},
			600:{items:3},
			1000:{items:4}
		},
		smartSpeed:70,
		onInitialized:function(e){
			$(e.target).find('img').each(function(){
				if(this.complete){
					$(this).closest('.mhn-inner').find('.loader-circle').hide();
					$(this).closest('.mhn-inner').find('.mhn-img').css('background-image','url('+$(e.target).attr('src')+')');
				}else{
					$(this).bind('load',function(e){
						$(e.target).closest('.mhn-inner').find('.loader-circle').hide();
						$(e.target).closest('.mhn-inner').find('.mhn-img').css('background-image','url('+$(e.target).attr('src')+')');
					});
				}
			});
		},
		navText:['<svg viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></svg>','<svg viewBox="0 0 24 24"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></svg>']
	});
});

// owl crousel-1 js close