const mongoose = require("mongoose");
const http = require("http"); // create a real HTTP server object so Socket.IO can attach to the same server as Express.

const express = require('express');
const app = express();
app.use(express.json());

const cors = require('cors');
app.use(cors({
    origin: "http://localhost:3000",
    credentials: true
}));

const port = 5000;

mongoose.connect('mongodb://127.0.0.1:27017/chatdb').then(() => console.log('Connected to MongoDB')).catch(err => console.log(err));

const messageSchema = new mongoose.Schema({ sender: String, text: String, timestamp: { type: Date, default: Date.now } });

const chatSchema = new mongoose.Schema({ taskerid: String, userid: String, messages: [messageSchema], });
var ChatModel = mongoose.model('Chat', chatSchema, 'Chat');

// Create real server (IMPORTANT)
const server = http.createServer(app); // create an actual Node HTTP server and attach the Express app to it. Important because Socket.IO needs the raw server to attach WebSocket upgrades.
const { Server } = require("socket.io"); // import the Server class from socket.io.

// SOCKET.IO INIT
// Socket.IO CORS options allow client connections from http://localhost:3001. This must match the client origin, otherwise the socket connection will fail.
const io = new Server(server, {
    cors: {
        origin: "http://localhost:3000",
        methods: ["GET", "POST"]
    }
});

// ===== SOCKET.IO HANDLING =====
// whenever the connection takes place , (socket) function will run , socket is like users
io.on("connection", (socket) =>    // fired for every new client socket connection
{
    console.log("🔌 Socket connected:", socket.id);

    socket.on("join_room", (roomId) =>
    {
        socket.join(roomId);
        console.log("📌 Joined room:", roomId);
    });

    socket.on("typing", ({ roomId, sender }) =>
    {
        // broadcast to everyone in the room except the sender
        socket.to(roomId).emit("typing", { sender });
    });


});

// ====== SEND MESSAGE API ======
app.post("/api/chat/send", async (req, res) =>
{
    const { sender, receiver, text } = req.body;

    let chat = await ChatModel.findOne({
        $or: [
            { userid: sender, taskerid: receiver },
            { userid: receiver, taskerid: sender }
        ]
    });

    const newMsg = { sender, text, timestamp: new Date() };

    if (!chat)
    {
        chat = new ChatModel({
            userid: sender,
            taskerid: receiver,
            messages: [newMsg]
        });
    }
    else
    {
        chat.messages.push(newMsg);
    }

    const saved = await chat.save();

    if (saved)
    {
        const roomId = `${chat.userid}_${chat.taskerid}`;

        // real-time emit
        io.to(roomId).emit("receive_message", newMsg);

        return res.status(200).json({ statuscode: 1, msg: newMsg });
    }

    res.status(200).json({ statuscode: 0 });
});

// ===== GET CHAT HISTORY =====
app.get("/api/chat/history", async (req, res) =>
{
    const { userid, taskerid } = req.query;

    const chat = await ChatModel.findOne({
        $or: [
            { userid: userid, taskerid: taskerid },
            { userid: taskerid, taskerid: userid }
        ]
    });

    res.json(chat ? chat.messages : []);
});

server.listen(port, () => console.log(`🚀 Server + WebSocket running at ${port}`));
