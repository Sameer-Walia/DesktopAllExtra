$(".div1").hide();
$(".size").click(function(){
    $(".div1").show(1000);
    $(".size").hide(1000);
})

$(".close").click(function(){
    $(".size").show(1000);
    $(".div1").hide(1000);
})


/* for next slide */
$(".right").click(function(){
    if($(".slide.active").next(".slide").length!=0)   /* from 1st slide to 3rd slide */
    {
        // $(".slide.active").hide(2000).removeClass("active").next(".slide").show(2000).addClass("active")
        // $(".slide.active").slideUp(2000).removeClass("active").next(".slide").slideDown(2000).addClass("active")  
        $(".slide.active").fadeOut(2000).removeClass("active").next(".slide").fadeIn(2000).addClass("active")            
            //  below of dots
        $("li.active2").removeClass("active2").next("li").addClass("active2")

    }
    else                        /* from 3rd slide to 1st slide */
    {
        $(".slide.active").fadeOut(2000).removeClass("active")
        $(".slide:first").fadeIn(2000).addClass("active")
            //  below of dots
        $("li.active2").removeClass("active2")
        $("li:first").addClass("active2")
    }
})

/* for previous slide */
$(".left").click(function(){
    if($(".slide.active").prev(".slide").length!=0)   /* from 1st slide to 3rd slide */
    {
        $(".slide.active").removeClass("active").prev(".slide").addClass("active")
                     //  below of dots
        $("li.active2").removeClass("active2").prev("li").addClass("active2")
}
    else                        /* from 3rd slide to 1st slide */
    {
        $(".slide.active").removeClass("active")
        $(".slide:last").addClass("active")
            //  below of dots
        $("li.active2").removeClass("active2")
        $("li:last").addClass("active2")
    }
})