$(".sun").hide()
$(".moon").click(function(){
    $(".moon").hide()
    $(".sun").show()
    $(".theme1").css({backgroundColor:"#182C44"})
    $(".theme2").css({backgroundColor:"#112339"})
    $("h1,h2,h3,h4,h5,h6,a,#services span,#solution li,#solution li span,.size").css({color:"white"})
    $(".ss").css({color:"black"})
    $("p").css({color:"#c2c2c2"})
    $(".navbar h3").css({color:"#e4c904"})
    $("#solution .nav-item button").css({backgroundColor:"#112339",color:"white"})
    $("#solution .accordion-item,.accordion-button").css({backgroundColor:"#182C44",color:"white"})
    $("#gallery h6").css({color:"black"})

})
$(".sun").click(function(){
    $(".sun").hide()
    $(".moon").show()
    $(".theme1").css({backgroundColor:""})
    $(".theme2").css({backgroundColor:""})
    $("h1,h2,h3,h4,h5,h6,a,#services span,#solution li,#solution li span,.size").css({color:""})
    $(".ss").css({color:""})
    $("p").css({color:""})
    $("#solution .nav-item button").css({backgroundColor:"",color:""})
    $("#solution .accordion-item,.accordion-button").css({backgroundColor:"",color:""})
})

// // scroll effect( user define speed of scrolling)
// $("a.arrow").click(function(e){
//     // e.preventDefault();
//     // only applicable for one page website, it prevents page to reload or to naviagte to next page

//     var h = this.hash;  /* it gets hash(href) value of every anchor(a) tag */
//     $("html , body").animate({
//         scrollTop:$(h).offset().top  /* it navigate us to the top of that element */
//     },1500)  /* time in millisecond, "slow" , "fast"  */
// })

$("a.arrow").hide()
    $(window).scroll(function(){
        var s = $(window).scrollTop()   /* scrollTop() function is used to get window vertical scroll value(in pixel)*/
        if(s>100)
        {
            $("a.arrow").fadeIn(1000)
        }
        else
        {
            $("a.arrow").fadeOut(1000)
        }
})