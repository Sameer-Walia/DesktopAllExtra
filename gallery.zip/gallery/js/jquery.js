$(".sun").hide()
$(".moon").click(function(){
    $(".moon").hide()
    $(".sun").show()
    $(".theme1").css({backgroundColor:"#182C44"})
    $(".theme2").css({backgroundColor:"#112339"})
    $("h1,h2,h3,h4,h5,h6,a,#services span,#solution li,#solution li span,.size").css({color:"white"})
    $(".ss").css({color:"black"})
    $("p").css({color:"#c2c2c2"})
    $(".navbar h3").css({color:"#e4c904"})
    $("#solution .nav-item button").css({backgroundColor:"#112339",color:"white"})
    $("#solution .accordion-item,.accordion-button").css({backgroundColor:"#182C44",color:"white"})
    $("#gallery h6").css({color:"black"})

})
$(".sun").click(function(){
    $(".sun").hide()
    $(".moon").show()
    $(".theme1").css({backgroundColor:""})
    $(".theme2").css({backgroundColor:""})
    $("h1,h2,h3,h4,h5,h6,a,#services span,#solution li,#solution li span,.size").css({color:""})
    $(".ss").css({color:""})
    $("p").css({color:""})
    $("#solution .nav-item button").css({backgroundColor:"",color:""})
    $("#solution .accordion-item,.accordion-button").css({backgroundColor:"",color:""})
})






// Gallery image hover
$( ".img-wrapper" ).hover(
    function() {
      $(this).find(".img-overlay").animate({opacity: 1}, 600);
    }, function() {
      $(this).find(".img-overlay").animate({opacity: 0}, 600);
    }
  );
  
  // Lightbox
  var $overlay = $('<div id="overlay"></div>');
  var $image = $("<img>");
  var $prevButton = $('<div id="prevButton"><i class="fa fa-chevron-left"></i></div>');
  var $nextButton = $('<div id="nextButton"><i class="fa fa-chevron-right"></i></div>');
  var $exitButton = $('<div id="exitButton"><i class="fa fa-times"></i></div>');
  
  // Add overlay
  $overlay.append($image).prepend($prevButton).append($nextButton).append($exitButton);
  $("#gallery").append($overlay);
  
  // Hide overlay on default
  $overlay.hide();
  
  // When an image is clicked
  $(".img-overlay").click(function(event) {
    // Prevents default behavior
    event.preventDefault();
    // Adds href attribute to variable
    var imageLocation = $(this).prev().attr("href");
    // Add the image src to $image
    $image.attr("src", imageLocation);
    // Fade in the overlay
    $overlay.fadeIn("slow");
  });
  
  // When the overlay is clicked
  $overlay.click(function() {
    // Fade out the overlay
    $(this).fadeOut("slow");
  });
  
  // When next button is clicked
  $nextButton.click(function(event) {
    // Hide the current image
    $("#overlay img").hide();
    // Overlay image location
    var $currentImgSrc = $("#overlay img").attr("src");
    // Image with matching location of the overlay image
    var $currentImg = $('#image-gallery img[src="' + $currentImgSrc + '"]');
    // Finds the next image
    var $nextImg = $($currentImg.closest(".image").next().find("img"));
    // All of the images in the gallery
    var $images = $("#image-gallery img");
    // If there is a next image
    if ($nextImg.length > 0) { 
      // Fade in the next image
      $("#overlay img").attr("src", $nextImg.attr("src")).fadeIn(800);
    } else {
      // Otherwise fade in the first image
      $("#overlay img").attr("src", $($images[0]).attr("src")).fadeIn(800);
    }
    // Prevents overlay from being hidden
    event.stopPropagation();
  });
  
  // When previous button is clicked
  $prevButton.click(function(event) {
    // Hide the current image
    $("#overlay img").hide();
    // Overlay image location
    var $currentImgSrc = $("#overlay img").attr("src");
    // Image with matching location of the overlay image
    var $currentImg = $('#image-gallery img[src="' + $currentImgSrc + '"]');
    // Finds the next image
    var $nextImg = $($currentImg.closest(".image").prev().find("img"));
    // Fade in the next image
    $("#overlay img").attr("src", $nextImg.attr("src")).fadeIn(800);
    // Prevents overlay from being hidden
    event.stopPropagation();
  });
  
  // When the exit button is clicked
  $exitButton.click(function() {
    // Fade out the overlay
    $("#overlay").fadeOut("slow");
  });



  $(function(){
    $('.mhn-slide').owlCarousel({
      nav:true,
      //loop:true,
      slideBy:'page',
      rewind:false,
      responsive:{
        0:{items:1},
        480:{items:2},
        600:{items:3},
        1000:{items:4}
      },
      smartSpeed:70,
      onInitialized:function(e){
        $(e.target).find('img').each(function(){
          if(this.complete){
            $(this).closest('.mhn-inner').find('.loader-circle').hide();
            $(this).closest('.mhn-inner').find('.mhn-img').css('background-image','url('+$(e.target).attr('src')+')');
          }else{
            $(this).bind('load',function(e){
              $(e.target).closest('.mhn-inner').find('.loader-circle').hide();
              $(e.target).closest('.mhn-inner').find('.mhn-img').css('background-image','url('+$(e.target).attr('src')+')');
            });
          }
        });
      },
      navText:['<svg viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></svg>','<svg viewBox="0 0 24 24"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></svg>']
    });
  });